(declare-fun a () Real)
(assert (< 0.0 (/ (- 1.9) (- 1.9)) (/ 1.9 0.0)))
(check-sat-using qflia)