(declare-const x String)
(assert (xor (or (< 0 0) (str.prefixof "ab" (str.at "dcab" 0))) (not (>= 0 2))))
(assert (str.in_re (str.substr x 0 2) (re.++ (str.to_re (str.at (str.substr x (* 0 2) 2) (str.to_code x))) (re.* (re.range x (str.at "dcab" 2))))))
(check-sat)